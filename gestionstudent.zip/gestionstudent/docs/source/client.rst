client package
==============

Submodules
----------

client.utilities module
-----------------------

.. automodule:: client.utilities
   :members:
   :undoc-members:
   :show-inheritance:

client.vista module
-------------------

.. automodule:: client.vista
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: client
   :members:
   :undoc-members:
   :show-inheritance:
