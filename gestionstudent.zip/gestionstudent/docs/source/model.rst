model package
=============

Submodules
----------

model.modelo module
-------------------

.. automodule:: model.modelo
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: model
   :members:
   :undoc-members:
   :show-inheritance:
